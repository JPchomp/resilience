function [H] = flood_distance_arg(H_d,INT,SD)

% INT intensity of the storm at center
% SD spatial decay term
% H_d distances inherited from before
H = INT*100*normpdf(H_d, 0 , SD);