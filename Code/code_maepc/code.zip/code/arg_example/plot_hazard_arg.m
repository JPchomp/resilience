%% plot the surface of the hazard

x.min = min(xlocation)-1;
x.max = max(xlocation)+1;
y.min = min(ylocation)-1;
y.max = max(ylocation)+1;

%%
X = linspace(x.min,x.max,100);
Y = linspace(y.min,y.max,100);
[XX , YY] = meshgrid(X,Y);
%%
ZZ = hzsim_arg(XX, YY, 1, 1, 1, 1);

%%
set(gcf,'color','w');
p = plot(UGD,'XData',xlocation,'YData',ylocation);
hold on;
s = surf(XX,YY,ZZ,'FaceAlpha',0.5);
s.EdgeColor = 'none';
view(2);
cmap = colormap(1-hot);
cmap(1,:) = [1 1 1]; %Pure white
colormap(cmap);
colorbar
p.EdgeColor = 'k';