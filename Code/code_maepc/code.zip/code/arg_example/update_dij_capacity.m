function [dij] = update_dij_capacity(dij, haz_dist_matrix,linklist,INT,SD)

% Store the dimension will be useful
ll = length(linklist(:,1));

% This will store the distance from the center
H_d = zeros(ll,1);

for i = 1 : length(ll)
    % Get the index of from and to 
    idx_1 = linklist(i,1); idx_2 = linklist(i,2);
    % write a vector of the distances from the hazard
    H_d(i) =  haz_dist_matrix(idx_1,idx_2);
end
    % Get the flood intensity vector from the distance to center and INT
    H_f = flood_distance_arg(H_d,INT,SD);
    % Update the arc-path incidence matrix last column
    dij(:,end) = cap_hazard_arg(H_f,linklist(:,3));